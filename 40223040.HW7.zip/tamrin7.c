#include <stdio.h> //Mahdi Soleimani 40223040
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main()
{
    int n;
    printf("Please enter number of words: ");
    scanf("%d", &n);

    char(*lang1)[40] = malloc(n * sizeof(char[40]));
    char(*lang2)[40] = malloc(n * sizeof(char[40]));
    char(*lang1_new)[40] = malloc(n * sizeof(char[40]));
    char(*lang2_new)[40] = malloc(n * sizeof(char[40]));

    for (int i = 0; i < n; i++)
    {
        printf("word language 1: ");
        scanf("%s", lang1_new[i]);
        printf("word language 2: ");
        scanf("%s", lang2_new[i]);
    }
    for (int i = 0; i < n; i++)
    {
        strcpy(lang1[i], lang1_new[i]);
        strcpy(lang2[i], lang2_new[i]);
        for (int j = 0; j < strlen(lang1[i]); j++)
        {
            lang1[i][j] = tolower(lang1[i][j]);
        }
        for (int j = 0; j < strlen(lang2[i]); j++)
        {
            lang2[i][j] = tolower(lang2[i][j]);
        }
    }
    char sentence[100] = "";
    printf("Please write a sentence: ");
    getchar();
    scanf("%[^\n]", sentence);

    char result[100] = "";
    int input1_value = 0;

    while (sentence[input1_value] != '\0')
    {
        char word[100] = "";
        int input2_value = 0;
        while ((sentence[input1_value] != ' ') && sentence[input1_value] != '\0')
        {
            word[input2_value++] = sentence[input1_value++];
        }

        word[input2_value] = '\0';

        for (int i = 0; i < strlen(word); i++)
        {
            word[i] = tolower(word[i]);
        }

        int temp = 0;
        for (int i = 0; i < n; i++)
        {
            if (strcmp(lang1[i], word) == 0 && strlen(lang2[i]) < strlen(lang1[i]))
            {
                strcat(result, lang2_new[i]);
                temp = 1;
                break;
            }
            else if (strcmp(lang2[i], word) == 0 && strlen(lang1[i]) < strlen(lang2[i]))
            {
                strcat(result, lang1_new[i]);
                temp = 1;
                break;
            }
        }
        if (!temp)
        {
            strcat(result, word);
        }
        strcat(result, " ");
        if (sentence[input1_value] != '\0')
        {
            input1_value++;
        }
    }
    printf("%s\n", result);

    free(lang1);
    free(lang2);
    free(lang1_new);
    free(lang2_new);

    return 0;
}